## Admins

| Admin           | GitHub ID                               | Affiliation |
| --------------- | --------------------------------------- | ----------- |
| Henri Yandell   | [hyandell](https://github.com/hyandell) | Amazon      |

[This document](https://github.com/opensearch-project/.github/blob/main/ADMINS.md) explains what admins do in this repo. and how they should be doing it. If you're interested in becoming a maintainer, see [MAINTAINERS](MAINTAINERS.md). If you're interested in contributing, see [CONTRIBUTING](CONTRIBUTING.md).